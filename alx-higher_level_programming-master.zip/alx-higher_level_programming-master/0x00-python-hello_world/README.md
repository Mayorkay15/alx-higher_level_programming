Read me file for python
