#!/usr/bin/python3
# 10-add.py
# Brennan D Baraban <375@holbertonschool.com>


def add(a, b):
    """Return the addition of a and b."""
    return (a + b)
