#!/usr/bin/python3
# 5-raise_exception.py
# Brennan D Baraban <375@holbertonschool.com>


def raise_exception():
    """Raise a TypeError exception."""
    raise TypeError
