#!/usr/bin/python3
# 5-base_geometry.py
# Brennan D Baraban <375@holbertonschool.com>
"""Defines an empty class BaseGeometry."""


class BaseGeometry:
    """Represent base geometry."""
    pass
