Read me for Python
