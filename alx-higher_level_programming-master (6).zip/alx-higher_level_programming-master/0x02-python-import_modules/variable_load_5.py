#!/usr/bin/python3
a = 98
"""Simple variable
"""
