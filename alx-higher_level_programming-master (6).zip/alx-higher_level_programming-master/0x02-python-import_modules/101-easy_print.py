#!/usr/bin/python3
__import__("os").write(1, "#pythoniscool\n".encode("UTF-8"))
