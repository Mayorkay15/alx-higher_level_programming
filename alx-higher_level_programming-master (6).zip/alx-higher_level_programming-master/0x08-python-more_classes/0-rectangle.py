#!/usr/bin/python3
# 0-rectangle.py
# Brennan D Baraban <375@holbertonschool.com>
"""Defines a Rectangle class."""


class Rectangle:
    """Represent a rectangle."""
    pass
