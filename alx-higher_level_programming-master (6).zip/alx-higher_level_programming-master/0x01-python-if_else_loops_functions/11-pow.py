#!/usr/bin/python3
# 11-pow.py
# Brennan D Baraban <375@holbertonschool.com>


def pow(a, b):
    """Return a to the power of b."""
    return (a ** b)
