#!/usr/bin/python3
# 0-square.py
# Brennan D Baraban <375@holbertonschool.com>
"""Define a class Square."""


class Square:
    """Represent a square."""
    pass
